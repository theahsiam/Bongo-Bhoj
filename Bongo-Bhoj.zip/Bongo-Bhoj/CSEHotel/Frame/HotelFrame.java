package Frame;

import Entity.*; 
import java.lang.*;
import java.awt.*; 
import javax.swing.*; 
import javax.swing.border.TitledBorder;
import java.awt.event.*; 
import java.io.*; 

public class HotelFrame extends JFrame implements MouseListener, ActionListener
{
    private Font f1, f2, f3; 
    private Color c2;
    private JPanel panel;
    private JLabel title, Name, Pass, label6;
    private JTextField tfName;
    private JTextArea taReq, taShow;
    private double subtotal = 0; 
    private JPasswordField pPass;
    private JButton btnSubmit;
    private JButton bt1, bt2, bt3;
    private JButton gbt1, gbt2, gbt3, gbt4, gbt5, gbt6, gbt7, gbt8, gbt9, gbt10, gbt11, gbt12;
	private JRadioButton rbMild, rbMed, rbNaga, rbReg, rbLarge;
    private ButtonGroup bg1, bg2;
    private ButtonGroup bg3;  //vhorta
	
    // title labels top of picture
    private JLabel t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;

    // Food Image and Dropdowns
    private JLabel img1, img2, img3, img4, img5, img6, img7, img8, img9, img10, img11;
    private JComboBox q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11;
    private ImageIcon i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11;
	
    // Table 
    private JCheckBox cb1, cb2, cb3, cb4, cb5, cb6, cb7, cb8;
    
    public HotelFrame()
    {
        
        super("BONGO-BHOJ");
        super.setBounds(100, 10, 1310, 860); 
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        panel = new JPanel();
        panel.setLayout(null);
        c2 = new Color(240, 240, 240); 
        panel.setBackground(c2);
    
       
        f1 = new Font("Cambria", Font.BOLD, 38); 
        f2 = new Font("Cambria", Font.BOLD, 16); 
        f3 = new Font("Cambria", Font.BOLD, 18); 

        // Title
        title = new JLabel("BONGO-BHOJ");
        title.setBounds(505, 15, 300, 45);
        title.setFont(f1); 
        panel.add(title);

        // Dropdowns options
        String opts[] = {"0", "1", "2", "3", "4", "5"};

       
        t1 = new JLabel("RICE-30", SwingConstants.CENTER);
        t1.setBounds(30, 75, 150, 20);
        t1.setFont(f2);
        panel.add(t1);

        i1 = new ImageIcon("Picture/Picturefood1.png"); 
        img1 = new JLabel(i1); 
        img1.setBounds(30, 100, 150, 140);

        q1 = new JComboBox(opts); 
        q1.setBounds(30, 245, 150, 28); 
        q1.setFont(f3);

        t2 = new JLabel("KHICHURI-30", SwingConstants.CENTER);
        t2.setBounds(210, 75, 150, 20);
        t2.setFont(f2);
        panel.add(t2);

        i2 = new ImageIcon("Picture/Picturefood2.png"); 
        img2 = new JLabel(i2); 
        img2.setBounds(210, 100, 150, 140);

        q2 = new JComboBox(opts); 
        q2.setBounds(210, 245, 150, 28); 
        q2.setFont(f3);

        t3 = new JLabel("POLAO-30", SwingConstants.CENTER);
        t3.setBounds(390, 75, 150, 20);
        t3.setFont(f2);
        panel.add(t3);

        i3 = new ImageIcon("Picture/Picturefood3.png"); 
        img3 = new JLabel(i3); 
        img3.setBounds(390, 100, 150, 140);

        q3 = new JComboBox(opts); 
        q3.setBounds(390, 245, 150, 28); 
        q3.setFont(f3);

        
        // Item 4
        t4 = new JLabel("BEEF-220", SwingConstants.CENTER);
        t4.setBounds(30, 290, 150, 20);
        t4.setFont(f2);
        panel.add(t4);

        i4 = new ImageIcon("Picture/Picturefood4.png"); 
        img4 = new JLabel(i4); 
        img4.setBounds(30, 315, 150, 140);

        q4 = new JComboBox(opts); 
        q4.setBounds(30, 460, 150, 28); 
        q4.setFont(f3);

        t5 = new JLabel("CHICKEN-220", SwingConstants.CENTER);
        t5.setBounds(210, 290, 150, 20);
        t5.setFont(f2);
        panel.add(t5);

        i5 = new ImageIcon("Picture/Picturefood5.png"); 
        img5 = new JLabel(i5); 
        img5.setBounds(210, 315, 150, 140);

        q5 = new JComboBox(opts); 
        q5.setBounds(210, 460, 150, 28); 
        q5.setFont(f3);

        t6 = new JLabel("MUTTON-220", SwingConstants.CENTER);
        t6.setBounds(390, 290, 150, 20);
        t6.setFont(f2);
        panel.add(t6);
		
        t10 = new JLabel("Ilish-500", SwingConstants.CENTER);
        t10.setBounds(935, 290, 150, 20);
        t10.setFont(f2);
        panel.add(t10);

        i10 = new ImageIcon("Picture/elish.png");
        img10 = new JLabel(i10);
        img10.setBounds(935, 315, 150, 140);
        panel.add(img10);

        q10 = new JComboBox(opts);
        q10.setBounds(935, 460, 150, 28);
        q10.setFont(f3);
        panel.add(q10);

        t11 = new JLabel("Rui-500", SwingConstants.CENTER);
        t11.setBounds(1115, 290, 150, 20);
        t11.setFont(f2);
        panel.add(t11);

        i11 = new ImageIcon("Picture/lui.png");
        img11 = new JLabel(i11);
        img11.setBounds(1115, 315, 150, 140);
        panel.add(img11);

        q11 = new JComboBox(opts);
        q11.setBounds(1115, 460, 150, 28);
        q11.setFont(f3);
        panel.add(q11);

        i6 = new ImageIcon("Picture/Picturefood6.png"); 
        img6 = new JLabel(i6); 
        img6.setBounds(390, 315, 150, 140);

        q6 = new JComboBox(opts); 
        q6.setBounds(390, 460, 150, 28); 
        q6.setFont(f3);

        
        // Item 7
        t7 = new JLabel("WATER-30", SwingConstants.CENTER);
        t7.setBounds(30, 505, 150, 20);
        t7.setFont(f2);
        panel.add(t7);

        i7 = new ImageIcon("Picture/Picturefood7.png"); 
        img7 = new JLabel(i7); 
        img7.setBounds(30, 530, 150, 140);

        q7 = new JComboBox(opts); 
        q7.setBounds(30, 675, 150, 28); 
        q7.setFont(f3);

        // Item 8
        t8 = new JLabel("Seven up-30", SwingConstants.CENTER);
        t8.setBounds(210, 505, 150, 20);
        t8.setFont(f2);
        panel.add(t8);

        i8 = new ImageIcon("Picture/Picturefood8.png"); 
        img8 = new JLabel(i8); 
        img8.setBounds(210, 530, 150, 140);

        q8 = new JComboBox(opts); 
        q8.setBounds(210, 675, 150, 28); 
        q8.setFont(f3);

        // Item 9
        t9 = new JLabel("PEPSI-30", SwingConstants.CENTER);
        t9.setBounds(390, 505, 150, 20);
        t9.setFont(f2);
        panel.add(t9);

        i9 = new ImageIcon("Picture/Picturefood9.png"); 
        img9 = new JLabel(i9); 
        img9.setBounds(390, 530, 150, 140);

        q9 = new JComboBox(opts); 
        q9.setBounds(390, 675, 150, 28); 
        q9.setFont(f3);

        panel.add(img1); panel.add(q1); panel.add(img2); panel.add(q2); panel.add(img3); panel.add(q3);
        panel.add(img4); panel.add(q4); panel.add(img5); panel.add(q5); panel.add(img6); panel.add(q6);
        panel.add(img7); panel.add(q7); panel.add(img8); panel.add(q8); panel.add(img9); panel.add(q9);

        // table Jcheck boxes
        cb1 = new JCheckBox("Table 1"); cb1.setBounds(630, 95, 120, 25);  cb1.setFont(f2); panel.add(cb1);
        cb5 = new JCheckBox("Table 5"); cb5.setBounds(755, 95, 120, 25);  cb5.setFont(f2); panel.add(cb5);

        cb2 = new JCheckBox("Table 2"); cb2.setBounds(630, 130, 120, 25); cb2.setFont(f2); panel.add(cb2);
        cb6 = new JCheckBox("Table 6"); cb6.setBounds(755, 130, 120, 25); cb6.setFont(f2); panel.add(cb6);

        cb3 = new JCheckBox("Table 3"); cb3.setBounds(630, 165, 120, 25); cb3.setFont(f2); panel.add(cb3);
        cb7 = new JCheckBox("Table 7"); cb7.setBounds(755, 165, 120, 25); cb7.setFont(f2); panel.add(cb7);

        cb4 = new JCheckBox("Table 4"); cb4.setBounds(630, 200, 120, 25); cb4.setFont(f2); panel.add(cb4);
        cb8 = new JCheckBox("Table 8"); cb8.setBounds(755, 200, 120, 25); cb8.setFont(f2); panel.add(cb8);

        // Spice and size
        rbMild = new JRadioButton("Mild");   rbMild.setBounds(609, 365, 85, 30);  rbMild.setFont(f3); panel.add(rbMild);
        rbMed  = new JRadioButton("Medium"); rbMed.setBounds(704, 365, 105, 30); rbMed.setFont(f3);  panel.add(rbMed);
        rbNaga = new JRadioButton("Naga");   rbNaga.setBounds(819, 365, 90, 30);  rbNaga.setFont(f3);  panel.add(rbNaga);
        bg1 = new ButtonGroup(); bg1.add(rbMild); bg1.add(rbMed); bg1.add(rbNaga);

        // amader radio buttons
        rbReg   = new JRadioButton("Regular"); rbReg.setBounds(636, 570, 110, 30);   rbReg.setFont(f3);   panel.add(rbReg);
        rbLarge = new JRadioButton("Large");   rbLarge.setBounds(764, 570, 110, 30); rbLarge.setFont(f3); panel.add(rbLarge);
        bg2 = new ButtonGroup(); bg2.add(rbReg); bg2.add(rbLarge);

        
        // Special Request Box
        
        label6 = new JLabel("        -Any special Request:");
        label6.setBounds(30, 745, 212, 60);
        label6.setFont(f3);
        label6.setBackground(Color.YELLOW);
        label6.setOpaque(true); //using for color overlapping
        label6.addMouseListener(this);
        panel.add(label6);

        taReq = new JTextArea();
        taReq.setBounds(247, 745, 293, 60); 
        taReq.setFont(f3);
        panel.add(taReq);

        // id and pass box
        Name = new JLabel("Seller ID:*");  
        Name.setBounds(600, 675, 100, 30);   
        Name.setFont(f3); 
        panel.add(Name);

        tfName = new JTextField();     
        tfName.setBounds(700, 673, 210, 30);     
        tfName.setFont(f3); 
        panel.add(tfName);

        Pass = new JLabel("Password:*"); 
        Pass.setBounds(600, 713, 100, 30);   
        Pass.setFont(f3); 
        panel.add(Pass);

        pPass = new JPasswordField(); 
        pPass.setBounds(700, 713, 170, 30);  
        pPass.setFont(f3); 
        pPass.setEchoChar('$');
        pPass.addActionListener(this);
        panel.add(pPass);
		
		
        bt3 = new JButton("S");
        bt3.setBounds(870, 713, 40, 30);
        bt3.setFont(f2);
        bt3.setBackground(Color.BLUE);
        bt3.addActionListener(this);
        panel.add(bt3);

        //Submit Button
        bt1 = new JButton("Submit");
        bt1.setBounds(760, 758, 150, 47); 
        bt1.setFont(f3);
        bt1.setBackground(Color.GREEN); 
        bt1.addActionListener(this); 
        panel.add(bt1);
        
        bt2 = new JButton("Exit");
        bt2.setBounds(600, 758, 150,47);
        bt2.setFont(f2);
        bt2.setBackground(Color.RED);
        bt2.addActionListener(this);
        panel.add(bt2);
        

        // Grid of 12 buttons (3 Columns, 4 Rows) perfectly aligned with Row 2 pictures vertically
        bg3 = new ButtonGroup();

        // Button Grid Row 1 (y = 100)
        gbt1 = new JButton("Aloo"); gbt1.setBounds(950, 100, 90, 30); gbt1.setFont(f2); panel.add(gbt1);
        gbt2 = new JButton("Begun"); gbt2.setBounds(1055, 100, 90, 30); gbt2.setFont(f2); panel.add(gbt2);
        gbt3 = new JButton("Dal"); gbt3.setBounds(1160, 100, 90, 30); gbt3.setFont(f2); panel.add(gbt3);

        // Button Grid Row 2 (y = 135)
        gbt4 = new JButton("Shim"); gbt4.setBounds(950, 135, 90, 30); gbt4.setFont(f2); panel.add(gbt4);
        gbt5 = new JButton("Potol"); gbt5.setBounds(1055, 135, 90, 30); gbt5.setFont(f2); panel.add(gbt5);
        gbt6 = new JButton("Lau"); gbt6.setBounds(1160, 135, 90, 30); gbt6.setFont(f2); panel.add(gbt6);

        // Button Grid Row 3 (y = 170)
        gbt7 = new JButton("Chingri"); gbt7.setBounds(950, 170, 90, 30); gbt7.setFont(f2); panel.add(gbt7);
        gbt8 = new JButton("Taki"); gbt8.setBounds(1055, 170, 90, 30); gbt8.setFont(f2); panel.add(gbt8);
        gbt9 = new JButton("Shutki"); gbt9.setBounds(1160, 170, 90, 30); gbt9.setFont(f2); panel.add(gbt9);

        // Button Grid Row 4 (y = 205)
        gbt10 = new JButton("Dim"); gbt10.setBounds(950, 205, 90, 30); gbt10.setFont(f2); panel.add(gbt10);
        gbt11 = new JButton("Peaj"); gbt11.setBounds(1055, 205, 90, 30); gbt11.setFont(f2); panel.add(gbt11);
        gbt12 = new JButton("Roshun"); gbt12.setBounds(1160, 205, 90, 30); gbt12.setFont(f2); panel.add(gbt12);

        // Adding buttons to the logical ButtonGroup
        bg3.add(gbt1); bg3.add(gbt2); bg3.add(gbt3);
        bg3.add(gbt4); bg3.add(gbt5); bg3.add(gbt6);
        bg3.add(gbt7); bg3.add(gbt8); bg3.add(gbt9);
        bg3.add(gbt10); bg3.add(gbt11); bg3.add(gbt12);   
		
		//Add ActionListeners to Vorta Buttons ---
        JButton[] vortas = {gbt1, gbt2, gbt3, gbt4, gbt5, gbt6, gbt7, gbt8, gbt9, gbt10, gbt11, gbt12};
        for(JButton btn : vortas) {
            btn.addActionListener(this);
        }

        // --- NEWLY ADDED CODES FOR DETACHED BACKGROUND TITLED BORDERS ---
        // 1st Border: table
        JPanel borderTable = new JPanel();
        borderTable.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Table", TitledBorder.CENTER, TitledBorder.TOP, f2));
        borderTable.setBounds(598, 70, 295, 165);
        borderTable.setOpaque(false);
        panel.add(borderTable);

        // 2nd Border: spice
        JPanel borderSpice = new JPanel();
        borderSpice.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Spice Level", TitledBorder.CENTER, TitledBorder.TOP, f2));
        borderSpice.setBounds(585, 340, 330, 70);
        borderSpice.setOpaque(false);
        panel.add(borderSpice);

        // 3rd Border: size
        JPanel borderSize = new JPanel();
        borderSize.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Size", TitledBorder.CENTER, TitledBorder.TOP, f2));
        borderSize.setBounds(598, 545, 280, 70);
        borderSize.setOpaque(false);
        panel.add(borderSize);

        // 4th Border: Vorta
        JPanel borderVorta = new JPanel();
        borderVorta.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Vorta", TitledBorder.CENTER, TitledBorder.TOP, f2));
        borderVorta.setBounds(935, 70, 330, 180);
        borderVorta.setOpaque(false);
        panel.add(borderVorta);
		
        // Receipt Area
        taShow = new JTextArea();
        taShow.setEditable(false);
        taShow.setFont(f2);

        JScrollPane scrollPane = new JScrollPane(taShow);
        scrollPane.setBounds(935, 505, 330, 300);
        panel.add(scrollPane);

        taShow.append("========= BONGO-BHOJ RECEIPT =========\n\n");

        super.add(panel);
    }



    
    public void mousePressed(MouseEvent me) 
    { 
        if(me.getSource() == label6)
        {
            label6.setText("        -Any special Request:");
        }
        else { }
    }
    public void mouseReleased(MouseEvent me) 
    { 
        if(me.getSource() == label6)
        {
            label6.setText(" Tell us your preferences");
        }
        else { }
    }
    
    // --- ADDED THE 3 MISSING MOUSELISTENER METHODS BELOW TO FIX THE ERROR ---
    public void mouseClicked(MouseEvent me) {}
    public void mouseEntered(MouseEvent me) {}
    public void mouseExited(MouseEvent me) {}
    

    public void actionPerformed(ActionEvent ae)
    {   Object source = ae.getSource();
        
        //Vorta button color toggle logic ---
        if (source == gbt1 || source == gbt2 || source == gbt3 || source == gbt4 || 
            source == gbt5 || source == gbt6 || source == gbt7 || source == gbt8 || 
            source == gbt9 || source == gbt10 || source == gbt11 || source == gbt12) {
            
            JButton btn = (JButton) source;
            if (btn.getBackground() == Color.ORANGE) {
                btn.setBackground(null); // Unselect (returns to default color)
            } else {
                btn.setBackground(Color.ORANGE); // Select (turns orange)
            }
        }
		
        if(ae.getSource() == bt2)
        {
            System.exit(0);
        }

        if(ae.getSource() == bt3)
        {
            pPass.setEchoChar((char)0);
        }

        if(ae.getSource() == bt1)
        {
            try
            {
                String idStr = tfName.getText();
                String passStr = new String(pPass.getPassword());

                if(idStr.isEmpty() || passStr.isEmpty())
                {
                    JOptionPane.showMessageDialog(this, "Please fill up your User ID and Password!");
                }
                else
                {
                    taShow.setText("");
                    taShow.append("========= BONGO-BHOJ RECEIPT =========\n\n");

                    String spiceChoice = "";

                    if(rbMild.isSelected()) { spiceChoice = rbMild.getText(); }
                    else if(rbMed.isSelected()) { spiceChoice = rbMed.getText(); }
                    else if(rbNaga.isSelected()) { spiceChoice = rbNaga.getText(); }
                    else { spiceChoice = "Not Selected"; }

                    String portionChoice = "";

                    if(rbReg.isSelected()) { portionChoice = rbReg.getText(); }
                    else if(rbLarge.isSelected()) { portionChoice = rbLarge.getText(); }
                    else { portionChoice = "Not Selected"; }

                    String tableChoice = "";

                    if(cb1.isSelected()) { tableChoice += cb1.getText() + " "; }
                    if(cb2.isSelected()) { tableChoice += cb2.getText() + " "; }
                    if(cb3.isSelected()) { tableChoice += cb3.getText() + " "; }
                    if(cb4.isSelected()) { tableChoice += cb4.getText() + " "; }
                    if(cb5.isSelected()) { tableChoice += cb5.getText() + " "; }
                    if(cb6.isSelected()) { tableChoice += cb6.getText() + " "; }
                    if(cb7.isSelected()) { tableChoice += cb7.getText() + " "; }
                    if(cb8.isSelected()) { tableChoice += cb8.getText() + " "; }

                    if(tableChoice.isEmpty())
                    {
                        tableChoice = "None";
                    }

                    taShow.append("Seller ID : " + idStr + "\n");
                    taShow.append("Table : " + tableChoice + "\n");
                    taShow.append("Spice : " + spiceChoice + "\n");
                    taShow.append("Size : " + portionChoice + "\n\n");

                    subtotal = 0;

                    int qty1 = Integer.parseInt(q1.getSelectedItem().toString());
                    int qty2 = Integer.parseInt(q2.getSelectedItem().toString());
                    int qty3 = Integer.parseInt(q3.getSelectedItem().toString());
                    int qty4 = Integer.parseInt(q4.getSelectedItem().toString());
                    int qty5 = Integer.parseInt(q5.getSelectedItem().toString());
                    int qty6 = Integer.parseInt(q6.getSelectedItem().toString());
                    int qty7 = Integer.parseInt(q7.getSelectedItem().toString());
                    int qty8 = Integer.parseInt(q8.getSelectedItem().toString());
                    int qty9 = Integer.parseInt(q9.getSelectedItem().toString());
                    int qty10 = Integer.parseInt(q10.getSelectedItem().toString());
                    int qty11 = Integer.parseInt(q11.getSelectedItem().toString());

                    int total1 = qty1 * 30;
                    int total2 = qty2 * 30;
                    int total3 = qty3 * 30;
                    int total4 = qty4 * 220;
                    int total5 = qty5 * 220;
                    int total6 = qty6 * 220;
                    int total7 = qty7 * 30;
                    int total8 = qty8 * 30;
                    int total9 = qty9 * 30;
                    int total10 = qty10 * 500;
                    int total11 = qty11 * 500;

                    if(qty1 > 0)
                    {
                        taShow.append("Rice x " + qty1 + " = " + total1 + " Tk\n");
                        subtotal += total1;
                    }

                    if(qty2 > 0)
                    {
                        taShow.append("Khichuri x " + qty2 + " = " + total2 + " Tk\n");
                        subtotal += total2;
                    }

                    if(qty3 > 0)
                    {
                        taShow.append("Polao x " + qty3 + " = " + total3 + " Tk\n");
                        subtotal += total3;
                    }

                    if(qty4 > 0)
                    {
                        taShow.append("Beef x " + qty4 + " = " + total4 + " Tk\n");
                        subtotal += total4;
                    }

                    if(qty5 > 0)
                    {
                        taShow.append("Chicken x " + qty5 + " = " + total5 + " Tk\n");
                        subtotal += total5;
                    }

                    if(qty6 > 0)
                    {
                        taShow.append("Mutton x " + qty6 + " = " + total6 + " Tk\n");
                        subtotal += total6;
                    }

                    if(qty7 > 0)
                    {
                        taShow.append("Water x " + qty7 + " = " + total7 + " Tk\n");
                        subtotal += total7;
                    }

                    if(qty8 > 0)
                    {
                        taShow.append("Seven Up x " + qty8 + " = " + total8 + " Tk\n");
                        subtotal += total8;
                    }

                    if(qty9 > 0)
                    {
                        taShow.append("Pepsi x " + qty9 + " = " + total9 + " Tk\n");
                        subtotal += total9;
                    }

                    if(qty10 > 0)
                    {
                        taShow.append("Ilish x " + qty10 + " = " + total10 + " Tk\n");
                        subtotal += total10;
                    }

                    if(qty11 > 0)
                    {
                        taShow.append("Rui x " + qty11 + " = " + total11 + " Tk\n");
                        subtotal += total11;
                    }

                    
                    JButton[] vortas = {gbt1, gbt2, gbt3, gbt4, gbt5, gbt6, gbt7, gbt8, gbt9, gbt10, gbt11, gbt12};
                        for(JButton btn : vortas) {
                    
                    if(btn.getBackground() == Color.ORANGE) {
                    taShow.append("Vorta : " + btn.getText() + " = 30 Tk\n");
                    subtotal += 30; // Adds 30 Tk for each orange button found
                      }
                    }

                    double vat = subtotal * 0.05;
                    double grandTotal = subtotal + vat;

                    taShow.append("\n--------------------------------\n");
                    taShow.append("Subtotal : " + subtotal + " Tk\n");
                    taShow.append("VAT (5%) : " + vat + " Tk\n");
                    taShow.append("Grand Total : " + grandTotal + " Tk\n");

                    if(!taReq.getText().isEmpty())
                    {
                        taShow.append("\nSpecial Request :\n");
                        taShow.append(taReq.getText() + "\n");
                    }

                    taShow.append("\nThank You For Visiting!\n");

                    String productQuantities = taShow.getText();

                    Customer targetCustomerObj = new Customer(
                        idStr,
                        passStr,
                        spiceChoice,
                        tableChoice,
                        productQuantities,
                        taReq.getText()
                    );

                    targetCustomerObj.insertInfo();

                    JOptionPane.showMessageDialog(this, "Thank you. The order has been received.");
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, "Something went wrong!");
            }
        }
    }

}