//step 6
import java.lang.*;
import Frame.*;

public class Start 
{
	public static void main(String[] args)
	{
		HotelFrame obj1 = new HotelFrame(); // Changed to HotelFrame
		obj1.setVisible(true);
	}
}