package Entity;
import java.lang.*;
import javax.swing.*; 
import java.io.*; 
import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter; 

public class Customer 
{
	private String s1; 
	private String s2; 
	private String s3; 
	private String s4; 
	private String s5; 
	private String s6; 
	
	private File file; 
	private FileWriter fwriter; 
	
	public Customer() { } 
	
	public Customer(String s1, String s2, String s3, String s4, String s5, String s6) 
	{
		this.s1 = s1; 
		this.s2 = s2; 
		this.s3 = s3; 
		this.s4 = s4; 
		this.s5 = s5; 
		this.s6 = s6; 
	}
	
	public void insertInfo() 
	{
		try 
		{
			file = new File("./Data/userdata.txt"); 
			if (!file.exists()) { 
				file.getParentFile().mkdirs(); 
				file.createNewFile(); 
			}
			
			LocalDateTime myDateObj = LocalDateTime.now(); 
			DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm a, dd/MM/yyyy"); 
			String timeAndDate = myDateObj.format(myFormatObj); 
			
			fwriter = new FileWriter(file, true); 
			fwriter.write("Date and Time: " + timeAndDate + "\n"); 
			fwriter.write("========================================================\n"); 
			fwriter.write("User ID: " + s1 + "\n");
			fwriter.write("Password: " + s2 + "\n");
			fwriter.write("Spice Level: " + s3 + "\n");
			fwriter.write("Table Assigned: " + s4 + "\n");
			fwriter.write("Quantities Ordered: " + s5 + "\n");
			fwriter.write("Special Requests: " + s6 + "\n");
			fwriter.write("--------------------------------------------------------\n"); 
			fwriter.flush(); 
			fwriter.close(); 
		}
		catch(IOException ioe) 
		{
			ioe.printStackTrace(); 
			JOptionPane.showMessageDialog(null, "Error writing data to system disk file!"); 
		}
	}
}